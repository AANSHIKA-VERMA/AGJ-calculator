"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Settings,
  Calculator,
  IndianRupee,
  Weight,
  Percent,
  Receipt,
  ArrowUpDown,
  TrendingUp,
  DollarSign,
} from "lucide-react"

interface GoldRates {
  "24k": number
  "22k": number
  "18k": number
  "14k": number
}

interface SilverRates {
  buybackRate: number
  sellingRate: number
}

interface MakingChargeRange {
  minWeight: number
  maxWeight: number
  percentage: number
}

interface GoldCalculationResult {
  goldValue: number
  makingCharges: number
  gstAmount: number
  totalAmount: number
  breakdown: {
    karat: string
    weight: number
    goldRate: number
    makingPercentage: number
    gstPercentage: number
  }
}

interface SilverCalculationResult {
  customerOffer: number
  realValue?: number
  profit?: number
  breakdown: {
    weight: number
    assumedPurity: number
    buybackRate: number
    actualPurity?: number
    sellingRate: number
  }
}

export default function JewelryCalculator() {
  // Gold Calculator States
  const [goldRates, setGoldRates] = useState<GoldRates>({
    "24k": 0,
    "22k": 0,
    "18k": 0,
    "14k": 0,
  })

  // Silver Rates State
  const [silverRates, setSilverRates] = useState<SilverRates>({
    buybackRate: 0,
    sellingRate: 0,
  })

  const [makingChargeRanges, setMakingChargeRanges] = useState<MakingChargeRange[]>([
    { minWeight: 0.5, maxWeight: 5, percentage: 14 },
    { minWeight: 5, maxWeight: 20, percentage: 12 },
    { minWeight: 20, maxWeight: 1000, percentage: 10 },
  ])

  const [selectedKarat, setSelectedKarat] = useState<keyof GoldRates>("22k")
  const [goldWeight, setGoldWeight] = useState<string>("")
  const [customMakingCharge, setCustomMakingCharge] = useState<string>("")
  const [gstPercentage, setGstPercentage] = useState<string>("3")
  const [goldResult, setGoldResult] = useState<GoldCalculationResult | null>(null)
  const [isSetupComplete, setIsSetupComplete] = useState(false)

  // Silver Calculator States
  const [silverWeight, setSilverWeight] = useState<string>("")
  const [assumedPurity, setAssumedPurity] = useState<string>("")
  const [actualPurity, setActualPurity] = useState<string>("")
  const [silverResult, setSilverResult] = useState<SilverCalculationResult | null>(null)

  // Active calculator tab
  const [activeTab, setActiveTab] = useState("gold")

  // Load data from localStorage on component mount
  useEffect(() => {
    const savedRates = localStorage.getItem("goldRates")
    const savedSilverRates = localStorage.getItem("silverRates")
    const savedRanges = localStorage.getItem("makingChargeRanges")
    const setupDate = localStorage.getItem("setupDate")

    if (savedRates && savedSilverRates && savedRanges && setupDate) {
      const today = new Date().toDateString()
      if (setupDate === today) {
        setGoldRates(JSON.parse(savedRates))
        setSilverRates(JSON.parse(savedSilverRates))
        setMakingChargeRanges(JSON.parse(savedRanges))
        setIsSetupComplete(true)
      }
    }
  }, [])

  const saveSetup = () => {
    const today = new Date().toDateString()
    localStorage.setItem("goldRates", JSON.stringify(goldRates))
    localStorage.setItem("silverRates", JSON.stringify(silverRates))
    localStorage.setItem("makingChargeRanges", JSON.stringify(makingChargeRanges))
    localStorage.setItem("setupDate", today)
    setIsSetupComplete(true)
  }

  const getMakingChargePercentage = (weightValue: number): number => {
    if (customMakingCharge) return Number.parseFloat(customMakingCharge)

    for (const range of makingChargeRanges) {
      if (weightValue >= range.minWeight && weightValue < range.maxWeight) {
        return range.percentage
      }
    }
    return makingChargeRanges[makingChargeRanges.length - 1].percentage
  }

  const calculateGoldTotal = () => {
    const weightValue = Number.parseFloat(goldWeight)
    const gstValue = Number.parseFloat(gstPercentage)
    const goldRate = goldRates[selectedKarat]

    if (!weightValue || !goldRate || !gstValue) return

    const goldValue = weightValue * goldRate
    const makingPercentage = getMakingChargePercentage(weightValue)
    const makingCharges = (goldValue * makingPercentage) / 100
    const subtotal = goldValue + makingCharges
    const gstAmount = (subtotal * gstValue) / 100
    const totalAmount = subtotal + gstAmount

    setGoldResult({
      goldValue,
      makingCharges,
      gstAmount,
      totalAmount,
      breakdown: {
        karat: selectedKarat,
        weight: weightValue,
        goldRate,
        makingPercentage,
        gstPercentage: gstValue,
      },
    })
  }

  const calculateSilverBuyback = () => {
    const weight = Number.parseFloat(silverWeight)
    const assumedPur = Number.parseFloat(assumedPurity)
    const actualPur = actualPurity ? Number.parseFloat(actualPurity) : undefined

    if (!weight || !assumedPur || !silverRates.buybackRate) return

    // Customer's offer = Weight × (Assumed Purity / 100) × Buyback Rate
    const customerOffer = weight * (assumedPur / 100) * silverRates.buybackRate

    let realValue: number | undefined
    let profit: number | undefined

    // Only calculate real value and profit if actual purity is provided
    if (actualPur !== undefined && silverRates.sellingRate) {
      // Real value = Weight × (Actual Purity / 100) × Selling Rate
      realValue = weight * (actualPur / 100) * silverRates.sellingRate
      // Profit = Real Value - Customer's Offer
      profit = realValue - customerOffer
    }

    setSilverResult({
      customerOffer,
      realValue,
      profit,
      breakdown: {
        weight,
        assumedPurity: assumedPur,
        buybackRate: silverRates.buybackRate,
        actualPurity: actualPur,
        sellingRate: silverRates.sellingRate,
      },
    })
  }

  const updateMakingRange = (index: number, field: keyof MakingChargeRange, value: number) => {
    const newRanges = [...makingChargeRanges]
    newRanges[index] = { ...newRanges[index], [field]: value }
    setMakingChargeRanges(newRanges)
  }

  const resetSetup = () => {
    localStorage.removeItem("goldRates")
    localStorage.removeItem("silverRates")
    localStorage.removeItem("makingChargeRanges")
    localStorage.removeItem("setupDate")
    setIsSetupComplete(false)
    setGoldResult(null)
    setSilverResult(null)
  }

  if (!isSetupComplete) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-yellow-50 via-amber-50 to-orange-50 p-4">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-5xl font-bold bg-gradient-to-r from-amber-600 to-yellow-600 bg-clip-text text-transparent mb-3">
              Jewelry Calculator Pro
            </h1>
            <p className="text-lg text-amber-700">Setup daily rates and making charges</p>
          </div>

          <Card className="shadow-2xl border-0 bg-white/80 backdrop-blur-sm">
            <CardHeader className="bg-gradient-to-r from-amber-500 via-yellow-500 to-orange-500 text-white rounded-t-lg">
              <CardTitle className="flex items-center gap-3 text-xl">
                <Settings className="h-7 w-7" />
                Daily Setup Configuration
              </CardTitle>
              <CardDescription className="text-amber-100 text-base">
                Configure today's gold rates, silver rates, and making charge ranges
              </CardDescription>
            </CardHeader>
            <CardContent className="p-8">
              <div className="grid lg:grid-cols-3 gap-8">
                {/* Gold Rates */}
                <div className="space-y-6">
                  <h3 className="text-2xl font-bold text-amber-900 mb-6 flex items-center gap-3">
                    <IndianRupee className="h-6 w-6" />
                    Gold Rates (₹/gram)
                  </h3>
                  <div className="space-y-5">
                    {Object.entries(goldRates).map(([karat, rate]) => (
                      <div key={karat} className="group">
                        <Label htmlFor={karat} className="text-base font-semibold text-gray-700 mb-2 block">
                          {karat.toUpperCase()} Gold Rate
                        </Label>
                        <Input
                          id={karat}
                          type="number"
                          placeholder="Enter rate per gram"
                          value={rate || ""}
                          onChange={(e) =>
                            setGoldRates((prev) => ({
                              ...prev,
                              [karat]: Number.parseFloat(e.target.value) || 0,
                            }))
                          }
                          className="h-12 text-lg border-2 border-amber-200 focus:border-amber-400 transition-colors"
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Silver Rates */}
                <div className="space-y-6">
                  <h3 className="text-2xl font-bold text-slate-700 mb-6 flex items-center gap-3">
                    <DollarSign className="h-6 w-6" />
                    Silver Rates (₹/gram)
                  </h3>
                  <div className="space-y-5">
                    <div className="group">
                      <Label htmlFor="buybackRate" className="text-base font-semibold text-gray-700 mb-2 block">
                        Buyback Silver Rate
                      </Label>
                      <Input
                        id="buybackRate"
                        type="number"
                        step="0.01"
                        placeholder="Rate offered to customers"
                        value={silverRates.buybackRate || ""}
                        onChange={(e) =>
                          setSilverRates((prev) => ({
                            ...prev,
                            buybackRate: Number.parseFloat(e.target.value) || 0,
                          }))
                        }
                        className="h-12 text-lg border-2 border-slate-200 focus:border-slate-400 transition-colors"
                      />
                    </div>
                    <div className="group">
                      <Label htmlFor="sellingRate" className="text-base font-semibold text-gray-700 mb-2 block">
                        Selling Silver Rate
                      </Label>
                      <Input
                        id="sellingRate"
                        type="number"
                        step="0.01"
                        placeholder="Market selling rate"
                        value={silverRates.sellingRate || ""}
                        onChange={(e) =>
                          setSilverRates((prev) => ({
                            ...prev,
                            sellingRate: Number.parseFloat(e.target.value) || 0,
                          }))
                        }
                        className="h-12 text-lg border-2 border-slate-200 focus:border-slate-400 transition-colors"
                      />
                    </div>
                  </div>
                </div>

                {/* Making Charge Ranges */}
                <div className="space-y-6">
                  <h3 className="text-2xl font-bold text-amber-900 mb-6 flex items-center gap-3">
                    <Percent className="h-6 w-6" />
                    Making Charge Ranges
                  </h3>
                  <div className="space-y-5">
                    {makingChargeRanges.map((range, index) => (
                      <div
                        key={index}
                        className="p-5 border-2 border-amber-200 rounded-xl bg-gradient-to-r from-amber-50 to-yellow-50"
                      >
                        <div className="grid grid-cols-3 gap-3">
                          <div>
                            <Label className="text-sm font-medium text-gray-600 mb-1 block">Min Weight (g)</Label>
                            <Input
                              type="number"
                              step="0.1"
                              value={range.minWeight}
                              onChange={(e) =>
                                updateMakingRange(index, "minWeight", Number.parseFloat(e.target.value) || 0)
                              }
                              className="h-10 border-amber-200"
                            />
                          </div>
                          <div>
                            <Label className="text-sm font-medium text-gray-600 mb-1 block">Max Weight (g)</Label>
                            <Input
                              type="number"
                              step="0.1"
                              value={range.maxWeight}
                              onChange={(e) =>
                                updateMakingRange(index, "maxWeight", Number.parseFloat(e.target.value) || 0)
                              }
                              className="h-10 border-amber-200"
                            />
                          </div>
                          <div>
                            <Label className="text-sm font-medium text-gray-600 mb-1 block">Charge (%)</Label>
                            <Input
                              type="number"
                              step="0.1"
                              value={range.percentage}
                              onChange={(e) =>
                                updateMakingRange(index, "percentage", Number.parseFloat(e.target.value) || 0)
                              }
                              className="h-10 border-amber-200"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="mt-10 text-center">
                <Button
                  onClick={saveSetup}
                  className="bg-gradient-to-r from-amber-500 via-yellow-500 to-orange-500 hover:from-amber-600 hover:via-yellow-600 hover:to-orange-600 text-white px-12 py-4 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
                  disabled={
                    !goldRates["24k"] ||
                    !goldRates["22k"] ||
                    !goldRates["18k"] ||
                    !goldRates["14k"] ||
                    !silverRates.buybackRate ||
                    !silverRates.sellingRate
                  }
                >
                  Save Setup & Continue to Calculator
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 p-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent mb-3">
            Jewelry Calculator Pro
          </h1>
          <p className="text-lg text-slate-600 mb-4">Professional gold pricing & silver buyback calculator</p>
          <Button
            variant="outline"
            onClick={resetSetup}
            className="border-2 border-slate-300 text-slate-700 hover:bg-slate-100 px-6 py-2"
          >
            Reset Daily Setup
          </Button>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-8 h-14 bg-white shadow-lg rounded-xl border-2">
            <TabsTrigger
              value="gold"
              className="text-base font-semibold data-[state=active]:bg-gradient-to-r data-[state=active]:from-amber-500 data-[state=active]:to-yellow-500 data-[state=active]:text-white rounded-lg"
            >
              <IndianRupee className="h-5 w-5 mr-2" />
              Gold Calculator
            </TabsTrigger>
            <TabsTrigger
              value="silver"
              className="text-base font-semibold data-[state=active]:bg-gradient-to-r data-[state=active]:from-slate-500 data-[state=active]:to-gray-500 data-[state=active]:text-white rounded-lg"
            >
              <ArrowUpDown className="h-5 w-5 mr-2" />
              Silver Buyback
            </TabsTrigger>
          </TabsList>

          <TabsContent value="gold" className="space-y-8">
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Gold Calculator */}
              <Card className="shadow-2xl border-0 bg-white/90 backdrop-blur-sm">
                <CardHeader className="bg-gradient-to-r from-amber-500 to-yellow-500 text-white rounded-t-lg">
                  <CardTitle className="flex items-center gap-3 text-xl">
                    <Calculator className="h-6 w-6" />
                    Gold Price Calculator
                  </CardTitle>
                  <CardDescription className="text-amber-100">
                    Calculate jewelry prices with detailed breakdown
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-8">
                  <div className="space-y-8">
                    {/* Karat Selection */}
                    <div>
                      <Label className="text-base font-semibold text-gray-700 mb-4 block">Select Gold Karat</Label>
                      <div className="grid grid-cols-2 gap-3">
                        {Object.entries(goldRates).map(([karat, rate]) => (
                          <Button
                            key={karat}
                            variant={selectedKarat === karat ? "default" : "outline"}
                            onClick={() => setSelectedKarat(karat as keyof GoldRates)}
                            className={`h-16 transition-all duration-300 ${
                              selectedKarat === karat
                                ? "bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600 shadow-lg"
                                : "border-2 border-amber-300 text-amber-700 hover:bg-amber-50"
                            }`}
                          >
                            <div className="text-center">
                              <div className="font-bold text-lg">{karat.toUpperCase()}</div>
                              <div className="text-sm opacity-90">₹{rate.toLocaleString()}</div>
                            </div>
                          </Button>
                        ))}
                      </div>
                    </div>

                    {/* Weight Input */}
                    <div>
                      <Label htmlFor="goldWeight" className="text-base font-semibold text-gray-700 mb-2 block">
                        Weight (grams)
                      </Label>
                      <div className="relative">
                        <Weight className="absolute left-4 top-4 h-5 w-5 text-gray-400" />
                        <Input
                          id="goldWeight"
                          type="number"
                          step="0.001"
                          placeholder="Enter weight in grams"
                          value={goldWeight}
                          onChange={(e) => setGoldWeight(e.target.value)}
                          className="pl-12 h-14 text-lg border-2 border-amber-200 focus:border-amber-400"
                        />
                      </div>
                    </div>

                    {/* Making Charges */}
                    <div>
                      <Label className="text-base font-semibold text-gray-700 mb-2 block">Making Charges</Label>
                      <div className="space-y-3">
                        {goldWeight && (
                          <div>
                            <Badge variant="secondary" className="bg-amber-100 text-amber-800 px-3 py-1 text-sm">
                              Auto: {getMakingChargePercentage(Number.parseFloat(goldWeight) || 0)}% (for {goldWeight}g)
                            </Badge>
                          </div>
                        )}
                        <Input
                          type="number"
                          step="0.1"
                          placeholder="Custom making charge % (optional)"
                          value={customMakingCharge}
                          onChange={(e) => setCustomMakingCharge(e.target.value)}
                          className="h-12 border-2 border-amber-200 focus:border-amber-400"
                        />
                      </div>
                    </div>

                    {/* GST */}
                    <div>
                      <Label htmlFor="gst" className="text-base font-semibold text-gray-700 mb-2 block">
                        GST Percentage
                      </Label>
                      <div className="relative">
                        <Percent className="absolute left-4 top-4 h-5 w-5 text-gray-400" />
                        <Input
                          id="gst"
                          type="number"
                          step="0.1"
                          placeholder="Enter GST percentage"
                          value={gstPercentage}
                          onChange={(e) => setGstPercentage(e.target.value)}
                          className="pl-12 h-14 text-lg border-2 border-amber-200 focus:border-amber-400"
                        />
                      </div>
                    </div>

                    <Button
                      onClick={calculateGoldTotal}
                      className="w-full bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600 text-white h-14 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
                      disabled={!goldWeight || !gstPercentage}
                    >
                      Calculate Gold Price
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Gold Results */}
              {goldResult && (
                <Card className="shadow-2xl border-0 bg-white/90 backdrop-blur-sm">
                  <CardHeader className="bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-t-lg">
                    <CardTitle className="flex items-center gap-3 text-xl">
                      <Receipt className="h-6 w-6" />
                      Gold Price Breakdown
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-8">
                    <div className="space-y-6">
                      {/* Total Amount */}
                      <div className="text-center p-6 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border-2 border-green-200">
                        <div className="text-4xl font-bold text-green-800 mb-2">
                          ₹{goldResult.totalAmount.toLocaleString("en-IN", { maximumFractionDigits: 2 })}
                        </div>
                        <div className="text-green-600 text-lg font-medium">Total Amount</div>
                      </div>

                      <Separator />

                      {/* Item Details */}
                      <div className="bg-slate-50 p-4 rounded-lg border">
                        <div className="text-sm text-slate-600 mb-2 font-medium">Item Specifications</div>
                        <div className="text-base space-y-1">
                          <div>
                            <span className="font-semibold">{goldResult.breakdown.karat.toUpperCase()} Gold</span>
                          </div>
                          <div>
                            <span className="font-semibold">{goldResult.breakdown.weight}g</span> @{" "}
                            <span className="font-semibold">₹{goldResult.breakdown.goldRate}/g</span>
                          </div>
                        </div>
                      </div>

                      {/* Breakdown */}
                      <div className="space-y-4">
                        <div className="flex justify-between items-center py-3 border-b border-gray-200">
                          <span className="text-gray-700 font-medium">Gold Value</span>
                          <span className="font-bold text-lg">
                            ₹{goldResult.goldValue.toLocaleString("en-IN", { maximumFractionDigits: 2 })}
                          </span>
                        </div>

                        <div className="flex justify-between items-center py-3 border-b border-gray-200">
                          <span className="text-gray-700 font-medium">
                            Making Charges ({goldResult.breakdown.makingPercentage}%)
                          </span>
                          <span className="font-bold text-lg">
                            ₹{goldResult.makingCharges.toLocaleString("en-IN", { maximumFractionDigits: 2 })}
                          </span>
                        </div>

                        <div className="flex justify-between items-center py-3 border-b border-gray-200">
                          <span className="text-gray-700 font-medium">GST ({goldResult.breakdown.gstPercentage}%)</span>
                          <span className="font-bold text-lg">
                            ₹{goldResult.gstAmount.toLocaleString("en-IN", { maximumFractionDigits: 2 })}
                          </span>
                        </div>

                        <div className="flex justify-between items-center py-4 bg-green-50 px-4 rounded-lg font-bold text-green-800 text-xl">
                          <span>Total Amount</span>
                          <span>₹{goldResult.totalAmount.toLocaleString("en-IN", { maximumFractionDigits: 2 })}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="silver" className="space-y-8">
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Silver Calculator */}
              <Card className="shadow-2xl border-0 bg-white/90 backdrop-blur-sm">
                <CardHeader className="bg-gradient-to-r from-slate-500 to-gray-600 text-white rounded-t-lg">
                  <CardTitle className="flex items-center gap-3 text-xl">
                    <ArrowUpDown className="h-6 w-6" />
                    Silver Buyback Calculator
                  </CardTitle>
                  <CardDescription className="text-slate-100">
                    Calculate silver buyback offers and profit margins
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-8">
                  <div className="space-y-6">
                    {/* Current Rates Display */}
                    <div className="bg-slate-50 p-4 rounded-lg border-2 border-slate-200">
                      <div className="text-sm text-slate-600 mb-2 font-medium">Today's Silver Rates</div>
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div className="flex justify-between">
                          <span>Buyback Rate:</span>
                          <span className="font-bold">₹{silverRates.buybackRate}/g</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Selling Rate:</span>
                          <span className="font-bold">₹{silverRates.sellingRate}/g</span>
                        </div>
                      </div>
                    </div>

                    {/* Weight */}
                    <div>
                      <Label htmlFor="silverWeight" className="text-base font-semibold text-gray-700 mb-2 block">
                        Weight (grams)
                      </Label>
                      <div className="relative">
                        <Weight className="absolute left-4 top-4 h-5 w-5 text-gray-400" />
                        <Input
                          id="silverWeight"
                          type="number"
                          step="0.001"
                          placeholder="Enter silver weight"
                          value={silverWeight}
                          onChange={(e) => setSilverWeight(e.target.value)}
                          className="pl-12 h-14 text-lg border-2 border-slate-200 focus:border-slate-400"
                        />
                      </div>
                    </div>

                    {/* Assumed Purity */}
                    <div>
                      <Label htmlFor="assumedPurity" className="text-base font-semibold text-gray-700 mb-2 block">
                        Assumed Purity (%)
                      </Label>
                      <div className="relative">
                        <Percent className="absolute left-4 top-4 h-5 w-5 text-gray-400" />
                        <Input
                          id="assumedPurity"
                          type="number"
                          step="0.1"
                          placeholder="Customer's claimed purity"
                          value={assumedPurity}
                          onChange={(e) => setAssumedPurity(e.target.value)}
                          className="pl-12 h-14 text-lg border-2 border-slate-200 focus:border-slate-400"
                        />
                      </div>
                    </div>

                    {/* Actual Purity - Optional */}
                    <div>
                      <Label htmlFor="actualPurity" className="text-base font-semibold text-gray-700 mb-2 block">
                        Actual Purity (%) <span className="text-sm text-gray-500 font-normal">- Optional</span>
                      </Label>
                      <div className="relative">
                        <Percent className="absolute left-4 top-4 h-5 w-5 text-gray-400" />
                        <Input
                          id="actualPurity"
                          type="number"
                          step="0.1"
                          placeholder="Tested actual purity (optional)"
                          value={actualPurity}
                          onChange={(e) => setActualPurity(e.target.value)}
                          className="pl-12 h-14 text-lg border-2 border-slate-200 focus:border-slate-400"
                        />
                      </div>
                      <div className="text-sm text-gray-500 mt-1">
                        Leave empty to show only customer offer. Fill to see profit analysis.
                      </div>
                    </div>

                    <Button
                      onClick={calculateSilverBuyback}
                      className="w-full bg-gradient-to-r from-slate-500 to-gray-600 hover:from-slate-600 hover:to-gray-700 text-white h-14 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
                      disabled={!silverWeight || !assumedPurity}
                    >
                      Calculate Silver Buyback
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Silver Results */}
              {silverResult && (
                <Card className="shadow-2xl border-0 bg-white/90 backdrop-blur-sm">
                  <CardHeader className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white rounded-t-lg">
                    <CardTitle className="flex items-center gap-3 text-xl">
                      <TrendingUp className="h-6 w-6" />
                      Silver Buyback Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-8">
                    <div className="space-y-6">
                      {/* Customer Offer - Always shown */}
                      <div className="text-center p-6 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border-2 border-blue-200">
                        <div className="text-4xl font-bold text-blue-800 mb-2">
                          ₹{silverResult.customerOffer.toLocaleString("en-IN", { maximumFractionDigits: 2 })}
                        </div>
                        <div className="text-blue-600 text-lg font-medium">Customer's Offer</div>
                      </div>

                      {/* Real Value and Profit - Only if actual purity provided */}
                      {silverResult.realValue !== undefined && silverResult.profit !== undefined && (
                        <>
                          <div className="grid grid-cols-1 gap-4">
                            <div className="text-center p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border-2 border-green-200">
                              <div className="text-2xl font-bold text-green-800">
                                ₹{silverResult.realValue.toLocaleString("en-IN", { maximumFractionDigits: 2 })}
                              </div>
                              <div className="text-green-600 font-medium">Real Market Value</div>
                            </div>

                            <div
                              className={`text-center p-4 rounded-xl border-2 ${
                                silverResult.profit >= 0
                                  ? "bg-gradient-to-r from-green-50 to-emerald-50 border-green-200"
                                  : "bg-gradient-to-r from-red-50 to-pink-50 border-red-200"
                              }`}
                            >
                              <div
                                className={`text-3xl font-bold ${
                                  silverResult.profit >= 0 ? "text-green-800" : "text-red-800"
                                }`}
                              >
                                ₹{Math.abs(silverResult.profit).toLocaleString("en-IN", { maximumFractionDigits: 2 })}
                              </div>
                              <div
                                className={`font-medium ${
                                  silverResult.profit >= 0 ? "text-green-600" : "text-red-600"
                                }`}
                              >
                                {silverResult.profit >= 0 ? "Profit" : "Loss"}
                              </div>
                            </div>
                          </div>

                          {/* Profit Margin */}
                          <div className="bg-gradient-to-r from-purple-50 to-indigo-50 p-4 rounded-lg border border-purple-200">
                            <div className="text-center">
                              <div className="text-lg font-bold text-purple-800">
                                Profit Margin: {((silverResult.profit / silverResult.customerOffer) * 100).toFixed(2)}%
                              </div>
                            </div>
                          </div>
                        </>
                      )}

                      <Separator />

                      {/* Calculation Details - Always shown */}
                      <div className="space-y-4">
                        <h4 className="font-bold text-gray-800 text-lg">Calculation Breakdown:</h4>

                        <div className="bg-slate-50 p-4 rounded-lg border space-y-2">
                          <div className="text-sm text-slate-600 font-medium">Silver Details</div>
                          <div className="text-sm space-y-1">
                            <div>
                              <span className="font-semibold">Weight:</span> {silverResult.breakdown.weight}g
                            </div>
                            <div>
                              <span className="font-semibold">Assumed Purity:</span>{" "}
                              {silverResult.breakdown.assumedPurity}%
                            </div>
                            {silverResult.breakdown.actualPurity && (
                              <div>
                                <span className="font-semibold">Actual Purity:</span>{" "}
                                {silverResult.breakdown.actualPurity}%
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200 space-y-2">
                          <div className="text-sm text-blue-800 font-medium">Calculation Formula:</div>
                          <div className="text-sm text-blue-700 space-y-1">
                            <div>
                              <strong>Customer Offer:</strong> {silverResult.breakdown.weight}g ×{" "}
                              {silverResult.breakdown.assumedPurity}% × ₹{silverResult.breakdown.buybackRate} = ₹
                              {silverResult.customerOffer.toFixed(2)}
                            </div>
                            {silverResult.realValue !== undefined && silverResult.profit !== undefined && (
                              <>
                                <div>
                                  <strong>Real Value:</strong> {silverResult.breakdown.weight}g ×{" "}
                                  {silverResult.breakdown.actualPurity}% × ₹{silverResult.breakdown.sellingRate} = ₹
                                  {silverResult.realValue.toFixed(2)}
                                </div>
                                <div>
                                  <strong>Profit/Loss:</strong> ₹{silverResult.realValue.toFixed(2)} - ₹
                                  {silverResult.customerOffer.toFixed(2)} = ₹{silverResult.profit.toFixed(2)}
                                </div>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        </Tabs>

        {/* Current Rates Display */}
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-slate-900 text-xl">Today's Rates & Configuration</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-8">
              <div>
                <h4 className="font-bold text-gray-800 mb-4 text-lg">Gold Rates (₹/gram)</h4>
                <div className="grid grid-cols-2 gap-3">
                  {Object.entries(goldRates).map(([karat, rate]) => (
                    <div
                      key={karat}
                      className="flex justify-between p-3 bg-amber-50 rounded-lg border border-amber-200"
                    >
                      <span className="font-semibold">{karat.toUpperCase()}</span>
                      <span className="font-bold">₹{rate.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="font-bold text-gray-800 mb-4 text-lg">Silver Rates (₹/gram)</h4>
                <div className="space-y-3">
                  <div className="flex justify-between p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <span className="font-medium">Buyback Rate</span>
                    <span className="font-bold">₹{silverRates.buybackRate.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <span className="font-medium">Selling Rate</span>
                    <span className="font-bold">₹{silverRates.sellingRate.toLocaleString()}</span>
                  </div>
                </div>
              </div>
              <div>
                <h4 className="font-bold text-gray-800 mb-4 text-lg">Making Charge Ranges</h4>
                <div className="space-y-3">
                  {makingChargeRanges.map((range, index) => (
                    <div
                      key={index}
                      className="flex justify-between p-3 bg-amber-50 rounded-lg border border-amber-200 text-sm"
                    >
                      <span className="font-medium">
                        {range.minWeight}g - {range.maxWeight}g
                      </span>
                      <span className="font-bold">{range.percentage}%</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
